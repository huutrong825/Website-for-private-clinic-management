function DelRow(){
    var table = document.getElementById("myTable");
    table.deleteRow(this);
}